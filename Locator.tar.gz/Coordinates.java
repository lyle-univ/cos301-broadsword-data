public class Coordinates{

	private double x;
	private double y;

	public Coordinates(){
		x = 0.00;
		y = 0.00;
	}

	public void setCoordinates(double _x, double _y){
		x = _x;
		y = _y;
	}

	public double getX(){ return x; }
	public double getY(){ return y; }

	public String getString(){ return "[X : "+Double.toString(x)+"]\n[Y : "+Double.toString(y)+"]"; }

}
