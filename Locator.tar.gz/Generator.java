import java.io.*;
import java.util.*;
import java.text.*;

public class Generator{
	public static void main(String[] args){
		try{
			FileWriter fw = new FileWriter("data.txt", true);

			for (int i = 0; i < 120; i++){
				String append = "";
				Random rnd = new Random();

				// This gives 1970 date, so just replace String version '1970' with '2017'
				long ms = 1491319131 + (Math.abs(rnd.nextLong()) % (365 * 24 * 60 * 60 * 1000)); 

				Date dt = new Date(ms);

				double x = -1899.99 + (1899.99 * 2.0) * rnd.nextDouble();
				double y = -1899.99 + (1899.99 * 2.0) * rnd.nextDouble();

				// Possible Mac Address, (Feel Free to Add More)
				String[] mac = {"00:A0:CC:23:AF:4A", 
								"0F:A1:34:6F:12:23", 
								"A1:22:A0:23:56:11", 
								"C9:34:28:23:FF:1F", 
								"B6:2D:33:90:C3:12", 
								"16:23:11:56:A1:89", 
								"AA:AA:A1:56:BA:23", 
								"51:22:73:D6:A4:DB", 	
								"E5:78:D4:82:23:A0", 
								"55:EE:56:12:AE:00", 
								"78:E4:14:00:A5:88", 
								"FF:56:FC:12:67:33"
								};

				int b =rnd.nextInt(12)+0;

				DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

				append = "{\"TimeStamp\":\""+df.format(dt)+"\", \"MacAddress\":\""+mac[b]+"\", \"X\":\""+Double.toString(x)+"\", \"Y\":\""+Double.toString(y)+"\"}\n";

				fw.write(append);
			}

			fw.close();
		}catch(IOException e){
			System.err.println("Error IOException: "+e.getMessage());
		}
	}
}
