import java.io.*;
import java.util.*;
import org.json.*;
import java.text.*;

public class Locater{

	private Coordinates current;

	public Locater(){
		current = new Coordinates();

	}

	public Coordinates getCoords(String mac_address){

		ArrayList<String> data = new ArrayList<String>();

		try{
			// Database of Mac Addresses and Coordinates
	
			BufferedReader 	in = new BufferedReader(new InputStreamReader(new FileInputStream("data.txt")));

			while (in.ready()){

				String line = in.readLine();

				// Add Only JSON Strings with relevant MAC Addresses
				if (line.contains(mac_address))
					data.add(line);						
			}

			try{
				// Act as the 'most current\latest date'
				String tmp = "01/01/1955 10:39:00";	
					
				DateFormat form = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

				try{
					Date date = form.parse(tmp);

					// Viewing purposes on terminal
					System.out.println("");

					// Go through all relevant Mac Addresses JSON Strings
					while (!data.isEmpty()){
						String p = data.remove(0).toString();
						
						System.out.println(p);

						JSONObject _ob = new JSONObject(p);
	
						String date_read = _ob.getString("TimeStamp");
						Date tmp_date = form.parse(date_read);

						// Check the currency of the read date
						if (date.before(tmp_date)){	
							date = tmp_date;
							// Update Latest Coordinates
							current.setCoordinates(Double.parseDouble(_ob.getString("X")), Double.parseDouble(_ob.getString("Y")));
						}
					
					}

					// For viewing purposes on terminal
					System.out.println("");
					// Return coordinate object with results
					return current;

				}catch(ParseException p){
					System.err.println("Error with Date conversion of Date! Date Corrupted");
					System.exit(1);
				}
						
			}catch(JSONException j){
				System.err.println("Error in Data Format! Format corrupted!");
				System.exit(1);
			}			

		}catch(IOException e){
			e.printStackTrace();
			System.err.println("Error in Data File! File corrupted!");
			System.exit(1);
		}

		return null;

		
	}
}
