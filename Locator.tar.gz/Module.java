import java.util.*;

public class Module{
	public static void main(String[] args){
		Coordinates myCoordinates = new Coordinates();
		Locater sponge_bob = new Locater();
		Scanner s          = new Scanner(System.in);

		System.out.println("Enter a MAC Address Below & SpongeBob will send you the coordinates of the Location:");
		myCoordinates = sponge_bob.getCoords(s.next());

		if (myCoordinates != null)
			System.out.println("The Location is:\n" + myCoordinates.getString());
		else
			System.out.println("Oops! The MAC Address you entered does not exist or could not be found!");

	}
}
