package javaapplication2;



import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Iterator;
import java.util.Map;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.runtime.jobmanager.JobManager;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

public class LocationStreaming {

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
       DataStream<String > inputStream=env.readTextFile("/home/seonin/example.txt");
        inputStream.map(new Sanitize()).print();
        env.execute("Location Streaming");
    }
    
    public static class Sanitize implements MapFunction<String, String>
    {
            @Override
            public String map(String value) throws Exception {
            JsonFactory JSONobject = new JsonFactory();
            ObjectMapper mapper = new ObjectMapper(JSONobject);
            String temp="";
            try {
                JsonNode rootNode = mapper.readTree(value);
                Iterator<Map.Entry<String,JsonNode>> fieldsIterator = rootNode.fields();
                while (fieldsIterator.hasNext()) 
                {
                    Map.Entry<String,JsonNode> node = fieldsIterator.next();
                   if(node.getKey()=="longitude"){
                    temp="";
                    while(node.getKey()!="ID")
                    {
                        if(node.getKey()=="longitude")
                        {
                            temp+="(x:"+node.getValue()+",";
                        }
                        if(node.getKey()=="latitude")
                        {
                            temp+="y:"+node.getValue()+")";
                        }
                        node = fieldsIterator.next();
                    }
                    return "User ID:"+node.getValue()+": "+temp+" Location: IT building";
                }
                    
                    
                    
                   
                }
                return rootNode.toString();
                }
                catch (java.io.IOException ex)
                {
                    return null;
                } 
    }
  }

 
}

