import java.io.*;
import java.util.*;

public class Module{

	public static void main(String[] args){
		Cleaner cleaner = new Cleaner();

		cleaner.clean(args[0]);
		cleaner.printOUT();
	}

}
