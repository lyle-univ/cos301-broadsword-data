import java.io.*;
import java.util.*;

import org.json.*;


public class Cleaner{

	private int[] coords;
	private String location;
	private String user;

	public Cleaner(){
		coords = new int[] {0, 0, 0};
		location = user = "";
	}

	public void clean(String jFile){
		String _content = null;
		File file = new File(jFile);
		FileReader reader = null;

		try{
			reader = new FileReader(file);
			char[] chars = new char[(int) file.length()];

			reader.read(chars);
			reader.close();

			_content = new String(chars);

			try{
			
				JSONObject _ob = new JSONObject(_content);

				JSONArray  _coordinates = new JSONArray(_ob.getJSONArray("Coords").toString());

				user = _ob.getString("userID");

				coords[0] = _coordinates.getInt(0);
				coords[1] = _coordinates.getInt(1);
				coords[2] = _coordinates.getInt(2);

			}catch(JSONException j){
				System.err.println(j);
				System.exit(1);
			}

			if ((coords[0] > -1) && ((coords[1] > -1) && (coords[2] > -1)))
				location = "Sci-Enza";
			else if ((coords[0] < 0) && ((coords[1] < 0) && (coords[2] < 0)))
				location = "Agricultural Building [Groud Level]";
			else if ((coords[0] > -1) && ((coords[1] > -1) && (coords[2] < 0)))
				location = "Thuto Building [Low Level]";
			else if ((coords[0] > -1) && ((coords[1] < 0) && (coords[2] > -1)))
				location = "Kloostersaal";
			else if ((coords[0] < 0) && ((coords[1] > -1) && (coords[2] > -1)))
				location = "Administration Building [The Ship]";
			else if ((coords[0] > -1) && ((coords[1] < 0) && (coords[2] < 0)))
				location = "AIM Labs";
			else if ((coords[0] < 0) && ((coords[1] < 0) && (coords[2] > -1)))
				location = "O.R Thambo Library [Law Building - Top Level]";
			else if ((coords[0] < 0) && ((coords[1] > -1) && (coords[2] < 0)))
				location = "Merensky Library [Study Centre]";
				

		}catch(IOException e){
			e.printStackTrace();
		}
	}

	public int[]  returnCoordinates(){ return coords; }
	public String returnLocation(){ return location; }

	public void printOUT(){
		System.out.println("\nUser "+user+" is at:\n");
		System.out.println("Coordinates <x, y, z>: [" + Integer.toString(coords[0]) + ", " + Integer.toString(coords[1]) + ", " + Integer.toString(coords[2]) + "]\n");
		System.out.println("Location name: " + location);
	}
	
}
